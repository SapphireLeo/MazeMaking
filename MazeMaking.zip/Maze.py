import os

SIZE_COL = 12
SIZE_ROW = 12
SIZE = 12
SQUARE_UNICODE = 9608
SQUARE = chr(SQUARE_UNICODE) * 2


def color_print(string, color):
    if color == 'BrightYellow':
        print('\x1b[93m' + string + '\x1b[0m', end='')


class Maze:
    def __init__(self):
        self.maze = [[1 for col in range(SIZE_COL)] for row in range(SIZE_ROW)]
        self.blank_point((0,1))
        self.blank_point((-1, -2))

    def print_maze(self):
        for y, row in enumerate(self.maze):
            for x, grid in enumerate(row):
                if grid == 1:
                    buffer = SQUARE + ' '
                else:
                    buffer = ' ' * 3
                if y == 0 or y == len(self.maze)-1 or x == 0 or x == len(row)-1:
                    color_print(buffer, 'BrightYellow')
                else:
                    print(buffer, end='')
            print()

    def clear_print(self):
        os.system('cls')  # not working on Pycharm IDE
        self.print_maze()

    def set_maze(self, new_maze):
        try:
            for y, row in enumerate(new_maze):
                
        self.maze = new_maze


    def wall_point(self, *args):
        for point in args:
            row = point[0]
            col = point[1]
            self.maze[row][col] = 1

    def blank_point(self, *args):
        for point in args:
            row = point[0]
            col = point[1]
            self.maze[row][col] = 0
