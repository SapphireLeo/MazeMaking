import Maze

maze = Maze.Maze()

maze.blank_point((1, 1),(2,1), (3, 1), (3, 2), (3, 3), (2, 3), (1, 3), (1, 4), (1, 5), (1, 6))
maze.blank_point((1, 1),(2,1), (3, 1), (3, 2), (3, 3), (2, 3), (1, 3))

maze.print_maze()

